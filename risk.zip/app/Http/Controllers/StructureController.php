<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Structure;

class StructureController extends Controller
{
   public function index()
    {
        return view('structure'); // create resources/views/dashboard.blade.php
    }
 public function store(Request $request)
    {
        $validated = $request->validate([
            'nom_structure' => 'required|string|max:255',
            'siret' => 'required|digits:14',
            'adresse' => 'required|string|max:255',
            'code_postal' => 'required|digits:5',
            'ville' => 'required|string|max:255',
            'email_contact' => 'required|email|max:255',
            'secteur_activite' => 'nullable|string|max:255',
            'nombre_employes' => 'nullable|string|max:255',
        ]);

        Structure::create($validated);

        return redirect()->back()->with('success', 'Structure enregistrée avec succès !');
    }
}
