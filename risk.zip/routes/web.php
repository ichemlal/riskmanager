<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\StructureController;
use App\Http\Controllers\MetiersController;
use App\Http\Controllers\SalariesController;
use App\Http\Controllers\CampagnesController;
use App\Http\Controllers\ResultatsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('/structure', [StructureController::class, 'index'])->name('structure');
Route::get('/metiers', [MetiersController::class, 'index'])->name('metiers');
Route::get('/salaries', [SalariesController::class, 'index'])->name('salaries');
Route::get('/campagnes', [CampagnesController::class, 'index'])->name('campagnes');
Route::get('/resultats', [ResultatsController::class, 'index'])->name('resultats');

Route::post('/structure/save', [StructureController::class, 'store'])->name('save.structure');
require __DIR__.'/auth.php';
