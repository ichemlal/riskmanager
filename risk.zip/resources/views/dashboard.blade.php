<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>
            <div class="content-wrapper">
                <!-- Page Header -->
                <div class="page-header">
                    <h1>Dashboard</h1>
                    <p>Vue d'ensemble de l'évaluation des risques professionnels</p>
                </div>

                <!-- Stats Grid -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon purple">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                                    <circle cx="9" cy="7" r="4"/>
                                    <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
                                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                                </svg>
                            </div>
                            <div class="stat-change positive">+12%</div>
                        </div>
                        <div class="stat-content">
                            <h3>234</h3>
                            <p>Participants total</p>
                        </div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon green">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
                                </svg>
                            </div>
                            <div class="stat-change positive">+8%</div>
                        </div>
                        <div class="stat-content">
                            <h3>89%</h3>
                            <p>Taux de participation</p>
                        </div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon blue">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect width="20" height="14" x="2" y="3" rx="2" ry="2"/>
                                    <line x1="8" x2="16" y1="21" y2="21"/>
                                    <line x1="12" x2="12" y1="17" y2="21"/>
                                </svg>
                            </div>
                            <div class="stat-change positive">+15%</div>
                        </div>
                        <div class="stat-content">
                            <h3>24</h3>
                            <p>Métiers analysés</p>
                        </div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon red">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                                    <line x1="12" x2="12" y1="9" y2="13"/>
                                    <line x1="12" x2="12.01" y1="17" y2="17"/>
                                </svg>
                            </div>
                            <div class="stat-change negative">-3%</div>
                        </div>
                        <div class="stat-content">
                            <h3>12</h3>
                            <p>Risques critiques</p>
                        </div>
                    </div>
                </div>

                <!-- Charts Grid -->
                <div class="charts-grid">
                    <div class="chart-card">
                        <h3>Participation par métier</h3>
                        <div class="chart-container">
                            Graphique des participations
                        </div>
                    </div>

                    <div class="chart-card">
                        <h3>Répartition des risques</h3>
                        <div class="chart-container">
                            Graphique des risques
                        </div>
                    </div>
                </div>

                <!-- Alerts -->
                <div class="alerts-card">
                    <h3>Alertes récentes</h3>
                    <div class="alerts-list">
                        <div class="alert critical">
                            <div class="alert-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                                    <line x1="12" x2="12" y1="9" y2="13"/>
                                    <line x1="12" x2="12.01" y1="17" y2="17"/>
                                </svg>
                            </div>
                            <div class="alert-content">
                                <div class="alert-title">Risque critique détecté</div>
                                <div class="alert-description">Exposition chimique dangereuse identifiée dans l'atelier de production</div>
                            </div>
                        </div>

                        <div class="alert warning">
                            <div class="alert-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                                    <line x1="12" x2="12" y1="9" y2="13"/>
                                    <line x1="12" x2="12.01" y1="17" y2="17"/>
                                </svg>
                            </div>
                            <div class="alert-content">
                                <div class="alert-title">Évaluation en retard</div>
                                <div class="alert-description">3 postes de travail n'ont pas encore été évalués</div>
                            </div>
                        </div>

                        <div class="alert success">
                            <div class="alert-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="20,6 9,17 4,12"/>
                                </svg>
                            </div>
                            <div class="alert-content">
                                <div class="alert-title">Évaluation terminée</div>
                                <div class="alert-description">Le service administratif a complété son évaluation des risques</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
</x-app-layout>
